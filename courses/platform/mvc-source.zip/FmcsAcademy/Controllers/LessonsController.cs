using Microsoft.AspNetCore.Mvc;
using FmcsAcademy.Services;
namespace FmcsAcademy.Controllers;
public class LessonsController(LessonRepository repository):Controller {
 public IActionResult Index() => View(repository.All);
 public IActionResult Detail(string id) {var lesson=repository.Find(id);return lesson is null?NotFound():View(lesson);}
 [HttpGet("lessons.json")] public IActionResult Data()=>Json(repository.All);
}