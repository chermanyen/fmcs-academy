using FmcsAcademy.Services;
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
builder.Services.AddSingleton<LessonRepository>();
var app = builder.Build();
app.UseStaticFiles();
app.MapControllerRoute("default", "{controller=Lessons}/{action=Index}/{id?}");
app.Run();