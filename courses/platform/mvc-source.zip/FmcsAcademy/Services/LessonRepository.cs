using System.Text.Json;
using FmcsAcademy.Models;
namespace FmcsAcademy.Services;
public class LessonRepository {
 public IReadOnlyList<Lesson> All {get;}
 public LessonRepository(IWebHostEnvironment env) {
  var json = File.ReadAllText(Path.Combine(env.ContentRootPath,"Data","lessons.json"));
  All = JsonSerializer.Deserialize<List<Lesson>>(json,new JsonSerializerOptions {PropertyNameCaseInsensitive=true}) ?? new();
 }
 public Lesson? Find(string id) => All.FirstOrDefault(x=>x.Id==id);
}