# 宇辰 FMCS Academy — ASP.NET Core MVC

## 啟動
安裝 .NET 8 SDK，在本目錄執行 `dotnet restore`、`dotnet build`、`dotnet run`，開啟終端顯示的 URL。

## IIS / Windows Server 2022
安裝相符的 ASP.NET Core Hosting Bundle，執行 `dotnet publish -c Release -o publish`。於 IIS 建立網站指向 publish，應用程式集區使用 No Managed Code；設定唯讀檔案權限及組織核准的 HTTPS / Windows 驗證政策。

## 維護
- Models/Lesson.cs：課程資料型別。
- Services/LessonRepository.cs：唯讀 JSON Repository。
- Controllers/LessonsController.cs：課程列表、Detail 與 JSON endpoint；不存在 id 回傳 404。
- Views：Razor SSR 頁面，共用 Layout。
- Data/lessons.json：單一課程資料來源；重新啟動服務載入修改。
- wwwroot：互動閱讀版，透過 /lessons.json 取得相同資料。完成度為瀏覽器 localStorage。

現階段不需要資料庫。多人進度、SSO、管理後台可在需求確認後加入，沒有預設帳密。

## 驗證與限制
交付環境沒有 .NET SDK，因此未執行 dotnet build 或 IIS 實機驗證；部署前必須執行以上建置流程。線上靜態教學版與 IIS MVC 版共用課程，但為兩個執行方式。模擬面板不連接 PLC。內部位址、權限與未取得的 SOP 沒有臆造。官方文件可能更新至 P04 / SP2，P03 選單須依安裝說明核對。
