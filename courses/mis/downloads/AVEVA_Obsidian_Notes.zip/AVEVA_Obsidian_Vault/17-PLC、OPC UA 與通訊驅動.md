---
title: "PLC、OPC UA 與通訊驅動"
tags: [AVEVA, FMCS, IT-MIS]
source_slide: 17
version: "2023 R2 SP1 P03 測試環境"
---


# PLC、OPC UA 與通訊驅動

> [!info] 章節與來源
> 04 通訊整合，對應簡報第 17 頁。
> 簡報概念插圖不代表軟體實際畫面，選單請以本機版本為準。

PLC：執行現場控制邏輯，提供狀態與命令點。

OPC UA：資料交換標準，具有節點與安全設定。

OI Server／Gateway：連接設備或 OPC 資料源。

DI Object：在 Galaxy 中組織通訊與點位參照。

OPC UA NodeId、PLC 地址、Attribute 名稱是不同層

## 補充說明與來源

可使用 AVEVA 驅動直接連線，或透過第三方 OPC Server，例如 Kepware。是否支援協定、加密及授權須依安裝的驅動確認。
資料來源：https://docs-be.aveva.com/bundle/sp-deployment-2023-r2/raw/resource/enus/sp-deployment-2023-r2.pdf

## 學習紀錄

- [ ] 我可以用自己的話解釋本節觀念。

- [ ] 我已完成適用的模擬練習。

- [ ] 我已記錄測試結果與待確認問題。

[[00-學習首頁|回學習首頁]]

上一節：[[16-部署問題的快速定位]]

下一節：[[18-實作 4：先接通一個唯讀溫度點]]
