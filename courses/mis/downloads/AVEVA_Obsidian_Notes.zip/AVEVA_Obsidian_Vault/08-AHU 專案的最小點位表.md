---
title: "AHU 專案的最小點位表"
tags: [AVEVA, FMCS, IT-MIS]
source_slide: 8
version: "2023 R2 SP1 P03 測試環境"
---


# AHU 專案的最小點位表

> [!info] 章節與來源
> 02 建立測試專案，對應簡報第 8 頁。
> 簡報概念插圖不代表軟體實際畫面，選單請以本機版本為準。

| 點位名稱 | 型別／單位 | 用途／資料方向 |
| --- | --- | --- |
| SupplyTemp | Float／°C | 送風溫度，唯讀輸入 |
| FanRun／FanFault | Boolean | 運轉回授／故障輸入 |
| FilterDP | Float／Pa | 濾網壓差輸入 |
| StartCmd／TempSP | Boolean／Float °C | 啟動命令／溫度設定輸出 |

範例名稱由本教材自訂，現場需建立正式點位規範

## 補充說明與來源

先定義命名、讀寫方向、量測範圍、預設值、故障值、單位與責任人。輸出點位先保持模擬，避免連到生產設備。
資料來源：https://docs-be.aveva.com/bundle/sp-deployment-2023-r2/raw/resource/enus/sp-deployment-2023-r2.pdf

## 學習紀錄

- [ ] 我可以用自己的話解釋本節觀念。

- [ ] 我已完成適用的模擬練習。

- [ ] 我已記錄測試結果與待確認問題。

[[00-學習首頁|回學習首頁]]

上一節：[[07-AHU：把空氣處理後送進空間]]

下一節：[[09-測試環境與版本基線]]
