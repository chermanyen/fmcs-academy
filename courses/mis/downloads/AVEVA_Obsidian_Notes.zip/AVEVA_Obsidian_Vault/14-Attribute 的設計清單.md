---
title: "Attribute 的設計清單"
tags: [AVEVA, FMCS, IT-MIS]
source_slide: 14
version: "2023 R2 SP1 P03 測試環境"
---


# Attribute 的設計清單

> [!info] 章節與來源
> 03 設備建模，對應簡報第 14 頁。
> 簡報概念插圖不代表軟體實際畫面，選單請以本機版本為準。

| 設計項目 | SupplyTemp 範例 | 檢查重點 |
| --- | --- | --- |
| 資料型別與單位 | Float，°C | 與 PLC 工程值一致 |
| I/O 與讀寫 | Input／唯讀 | 來源地址及轉換位置 |
| 警報條件 | High = 28°C（練習值） | 延遲、死區、嚴重度 |
| 歷史與安全 | 記錄溫度／限制寫入 | 採樣、權限與資料品質 |

先做點位規格，再操作設定畫面

## 補充說明與來源

資料來源：https://docs-be.aveva.com/bundle/sp-deployment-2023-r2/raw/resource/enus/sp-deployment-2023-r2.pdf

## 學習紀錄

- [ ] 我可以用自己的話解釋本節觀念。

- [ ] 我已完成適用的模擬練習。

- [ ] 我已記錄測試結果與待確認問題。

[[00-學習首頁|回學習首頁]]

上一節：[[13-實作 2：建立 AHU 範本與實例]]

下一節：[[15-實作 3：部署與即時檢查]]
