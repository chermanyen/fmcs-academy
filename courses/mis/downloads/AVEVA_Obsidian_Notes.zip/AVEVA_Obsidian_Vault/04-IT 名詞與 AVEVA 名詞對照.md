---
title: "IT 名詞與 AVEVA 名詞對照"
tags: [AVEVA, FMCS, IT-MIS]
source_slide: 4
version: "2023 R2 SP1 P03 測試環境"
---


# IT 名詞與 AVEVA 名詞對照

> [!info] 章節與來源
> 01 入門觀念，對應簡報第 4 頁。
> 簡報概念插圖不代表軟體實際畫面，選單請以本機版本為準。

| AVEVA 名詞 | IT 類比 | 類比的邊界 |
| --- | --- | --- |
| Galaxy | 應用專案與組態集合 | 不是單一執行程式 |
| IDE | Visual Studio 開發環境 | 設定物件與圖控為主 |
| Template／Instance | Class／Object | 另外包含警報與 I/O 組態 |
| Attribute | Property／狀態欄位 | 可附品質、警報與歷史設定 |

先理解功能，再記英文名稱

## 補充說明與來源

資料來源：https://docs-be.aveva.com/bundle/sp-deployment-2023-r2/raw/resource/enus/sp-deployment-2023-r2.pdf

## 學習紀錄

- [ ] 我可以用自己的話解釋本節觀念。

- [ ] 我已完成適用的模擬練習。

- [ ] 我已記錄測試結果與待確認問題。

[[00-學習首頁|回學習首頁]]

上一節：[[03-FMCS：廠務設備的集中監控]]

下一節：[[05-平台元件各自負責什麼]]
