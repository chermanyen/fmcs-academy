---
title: "AHU：把空氣處理後送進空間"
tags: [AVEVA, FMCS, IT-MIS]
source_slide: 7
version: "2023 R2 SP1 P03 測試環境"
---


# AHU：把空氣處理後送進空間

> [!info] 章節與來源
> 01 入門觀念，對應簡報第 7 頁。
> 簡報概念插圖不代表軟體實際畫面，選單請以本機版本為準。

![](assets/ahu.png)

*AI 概念插畫，非產品截圖。*

AHU = Air Handling Unit，空調箱／空調機組。

濾網過濾空氣，盤管降溫或加熱。

風機送風，感測器回報溫度與壓差。

## 補充說明與來源

實際 AHU 可能含回風、混風、加濕、再熱與不同盤管配置。本圖僅用於基本辨識。
圖片為 AI 概念插畫，不是產品實際畫面。
資料來源：https://docs-be.aveva.com/bundle/sp-deployment-2023-r2/raw/resource/enus/sp-deployment-2023-r2.pdf

## 學習紀錄

- [ ] 我可以用自己的話解釋本節觀念。

- [ ] 我已完成適用的模擬練習。

- [ ] 我已記錄測試結果與待確認問題。

[[00-學習首頁|回學習首頁]]

上一節：[[06-一筆溫度資料的旅程]]

下一節：[[08-AHU 專案的最小點位表]]
