---
title: "Model View 與 Deployment View"
tags: [AVEVA, FMCS, IT-MIS]
source_slide: 11
version: "2023 R2 SP1 P03 測試環境"
---


# Model View 與 Deployment View

> [!info] 章節與來源
> 02 建立測試專案，對應簡報第 11 頁。
> 簡報概念插圖不代表軟體實際畫面，選單請以本機版本為準。

| 視圖 | 回答的問題 | 練習配置 |
| --- | --- | --- |
| Model View | 設備在廠區的哪裡？ | Factory_A／AHU_Area |
| Deployment View | 物件由哪台主機執行？ | LAB_Platform／LAB_Engine |
| Area | 邏輯分組與警報組織 | AHU_Area |
| WinPlatform／AppEngine | 執行節點／物件執行引擎 | 承載 AHU_001 |

業務模型與執行位置分開思考

## 流程圖

```mermaid
flowchart TD
  W[WinPlatform 執行節點] --> E[AppEngine 執行引擎]
  E --> A[Area 區域]
  A --> I[AHU_001 設備實例]
  A --> J[AHU_002 設備實例]
```

## 補充說明與來源

WinPlatform 對應執行電腦。AppEngine 承載應用物件。先在 Deployment View 建立並配置主機、引擎與區域的 Hosting 關係；不能只建立模型樹就認為會執行。
資料來源：https://docs-be.aveva.com/bundle/sp-deployment-2023-r2/raw/resource/enus/sp-deployment-2023-r2.pdf

## 學習紀錄

- [ ] 我可以用自己的話解釋本節觀念。

- [ ] 我已完成適用的模擬練習。

- [ ] 我已記錄測試結果與待確認問題。

[[00-學習首頁|回學習首頁]]

上一節：[[10-實作 1：建立測試 Galaxy]]

下一節：[[12-Template 與 Instance 的繼承]]
