---
title: "FMCS：廠務設備的集中監控"
tags: [AVEVA, FMCS, IT-MIS]
source_slide: 3
version: "2023 R2 SP1 P03 測試環境"
---


# FMCS：廠務設備的集中監控

> [!info] 章節與來源
> 01 入門觀念，對應簡報第 3 頁。
> 簡報概念插圖不代表軟體實際畫面，選單請以本機版本為準。

![](assets/network.png)

*AI 概念插畫，非產品截圖。*

FMCS 管理空調、水、電與氣體等廠務狀態。

MIS 經驗可用於帳號、網路、資料與維運。

PLC 負責現場控制，SCADA 負責上層監控。

## 補充說明與來源

FMCS 展開為 Facility Monitoring and Control System。監控範圍依廠區而異。安全連鎖與即時控制應由經確認的現場控制設計處理。
圖片為 AI 概念插畫，不是產品實際畫面。
資料來源：https://docs-be.aveva.com/bundle/sp-deployment-2023-r2/raw/resource/enus/sp-deployment-2023-r2.pdf

## 學習紀錄

- [ ] 我可以用自己的話解釋本節觀念。

- [ ] 我已完成適用的模擬練習。

- [ ] 我已記錄測試結果與待確認問題。

[[00-學習首頁|回學習首頁]]

上一節：[[02-課程路線與學習成果]]

下一節：[[04-IT 名詞與 AVEVA 名詞對照]]
