---
title: "QuickScript .NET 與 C# 的對照"
tags: [AVEVA, FMCS, IT-MIS]
source_slide: 27
version: "2023 R2 SP1 P03 測試環境"
---


# QuickScript .NET 與 C# 的對照

> [!info] 章節與來源
> 07 腳本與系統整合，對應簡報第 27 頁。
> 簡報概念插圖不代表軟體實際畫面，選單請以本機版本為準。

| 目的 | C# 經驗 | QuickScript .NET 觀念 |
| --- | --- | --- |
| 設備屬性 | this.SupplyTemp | Me.SupplyTemp |
| 條件判斷 | if (...) { ... } | If ... Then ... EndIf; |
| 定時處理 | Timer／BackgroundService | Execute 搭配 Periodic 觸發 |
| 生命週期 | 啟動／停止事件 | Startup／Shutdown 等類型 |

語法不同，物件責任與可維護性原則相通

## 補充說明與來源

QuickScript .NET 不是 C#。範例為概念對照，正式語法以 Application Server Scripting Guide 為準。不要將 ASP.NET 或 WinForms 的執行緒模型直接搬進 AppEngine。
資料來源：https://docs-be.aveva.com/bundle/sp-deployment-2023-r2/raw/resource/enus/sp-deployment-2023-r2.pdf

## 學習紀錄

- [ ] 我可以用自己的話解釋本節觀念。

- [ ] 我已完成適用的模擬練習。

- [ ] 我已記錄測試結果與待確認問題。

[[00-學習首頁|回學習首頁]]

上一節：[[26-實作 7：溫度趨勢與歷史查詢]]

下一節：[[28-腳本執行時機]]
