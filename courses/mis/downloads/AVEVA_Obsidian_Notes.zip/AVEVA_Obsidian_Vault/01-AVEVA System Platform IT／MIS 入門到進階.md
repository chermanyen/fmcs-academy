---
title: "AVEVA System Platform IT／MIS 入門到進階"
tags: [AVEVA, FMCS, IT-MIS]
source_slide: 1
version: "2023 R2 SP1 P03 測試環境"
---


# AVEVA System Platform IT／MIS 入門到進階

> [!info] 章節與來源
> FMCS 技術教學，對應簡報第 1 頁。
> 簡報概念插圖不代表軟體實際畫面，選單請以本機版本為準。

用 C#、SQL Server 與 Windows 維運觀念
學會設備建模、圖控與系統整合

2023 R2 SP1 P03 測試環境　／　AHU 監控實作

## 補充說明與來源

建議分 6 次上課，每次 60 至 90 分鐘，另安排操作練習。已安裝軟體為起點，本教材不代替專案驗證或原廠相容性清單。
資料來源：https://docs-be.aveva.com/bundle/sp-getstarted-2023-r2/raw/resource/enus/sp-getstarted-2023-r2.pdf

## 學習紀錄

- [ ] 我可以用自己的話解釋本節觀念。

- [ ] 我已完成適用的模擬練習。

- [ ] 我已記錄測試結果與待確認問題。

[[00-學習首頁|回學習首頁]]

下一節：[[02-課程路線與學習成果]]
