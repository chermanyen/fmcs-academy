---
title: "Template 與 Instance 的繼承"
tags: [AVEVA, FMCS, IT-MIS]
source_slide: 12
version: "2023 R2 SP1 P03 測試環境"
---


# Template 與 Instance 的繼承

> [!info] 章節與來源
> 03 設備建模，對應簡報第 12 頁。
> 簡報概念插圖不代表軟體實際畫面，選單請以本機版本為準。

![](assets/inheritance.png)

*AI 概念插畫，非產品截圖。*

$AHU_Template 像設備 Class。

AHU_001、AHU_002 像兩個 Object。

共用邏輯放範本，各設備保留自己的點位。

## 流程圖

```mermaid
flowchart TD
  T[AHU_Template 共用定義] --> A[AHU_001]
  T --> B[AHU_002]
  A --> C[設備一點位來源]
  B --> D[設備二點位來源]
```

## 補充說明與來源

範本名稱使用 $ 前綴是常見 AVEVA 慣例。鎖定屬性限制衍生物件覆寫。變更傳播與實際執行更新須配合 Check In、驗證與重新部署。
圖片為 AI 概念插畫，不是產品實際畫面。
資料來源：https://docs-be.aveva.com/bundle/sp-deployment-2023-r2/raw/resource/enus/sp-deployment-2023-r2.pdf

## 學習紀錄

- [ ] 我可以用自己的話解釋本節觀念。

- [ ] 我已完成適用的模擬練習。

- [ ] 我已記錄測試結果與待確認問題。

[[00-學習首頁|回學習首頁]]

上一節：[[11-Model View 與 Deployment View]]

下一節：[[13-實作 2：建立 AHU 範本與實例]]
