---
title: "Historian 與 SQL Server 的分工"
tags: [AVEVA, FMCS, IT-MIS]
source_slide: 25
version: "2023 R2 SP1 P03 測試環境"
---


# Historian 與 SQL Server 的分工

> [!info] 章節與來源
> 06 警報與歷史，對應簡報第 25 頁。
> 簡報概念插圖不代表軟體實際畫面，選單請以本機版本為準。

| 項目 | Historian | 一般 SQL 業務資料 |
| --- | --- | --- |
| 典型資料 | 設備時間序列與品質 | 工單、設備主檔、申請紀錄 |
| 讀取方式 | 依產品支援的查詢介面 | 應用程式 SQL／API |
| 時間處理 | 採樣、壓縮與重取樣 | 依業務模型自行設計 |
| 變更原則 | 使用受支援工具設定 | 依自有 DB 變更流程 |

Galaxy Repository、Historian 與自建業務 DB 分別管理

## 補充說明與來源

Historian 的儲存與查詢架構不能簡化為一般關聯資料表。不要直接修改 GR 或 Historian 內部表。查詢介面與功能取決於安裝版本與授權。
資料來源：https://docs-be.aveva.com/bundle/sp-deployment-2023-r2/raw/resource/enus/sp-deployment-2023-r2.pdf

## 學習紀錄

- [ ] 我可以用自己的話解釋本節觀念。

- [ ] 我已完成適用的模擬練習。

- [ ] 我已記錄測試結果與待確認問題。

[[00-學習首頁|回學習首頁]]

上一節：[[24-實作 6：警報的四種狀態驗收]]

下一節：[[26-實作 7：溫度趨勢與歷史查詢]]
