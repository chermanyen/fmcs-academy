---
title: "實作 1：建立測試 Galaxy"
tags: [AVEVA, FMCS, IT-MIS]
source_slide: 10
version: "2023 R2 SP1 P03 測試環境"
---


# 實作 1：建立測試 Galaxy

> [!info] 章節與來源
> 02 建立測試專案，對應簡報第 10 頁。
> 簡報概念插圖不代表軟體實際畫面，選單請以本機版本為準。

1. 啟動 System Platform IDE，選擇 GR 節點。

2. 建立 Galaxy：FMCS_LAB，選用本機可用範本。

3. 建立完成後連線，確認可以瀏覽物件與範本。

4. 記錄 Galaxy 名稱、GR 主機與登入方式。

> [!success] 實作驗收
> 驗收：重新開啟 IDE 後，仍能連入 FMCS_LAB

## 補充說明與來源

選單名稱依安裝語系與版本可能不同。請在 Galaxy 連線對話框辨識 New Galaxy／Create Galaxy 功能。若未列出 GR，先確認主機名稱解析、GR 角色安裝及 SQL 服務。
資料來源：https://docs-be.aveva.com/bundle/sp-getstarted-2023-r2/raw/resource/enus/sp-getstarted-2023-r2.pdf

## 學習紀錄

- [ ] 我可以用自己的話解釋本節觀念。

- [ ] 我已完成適用的模擬練習。

- [ ] 我已記錄測試結果與待確認問題。

[[00-學習首頁|回學習首頁]]

上一節：[[09-測試環境與版本基線]]

下一節：[[11-Model View 與 Deployment View]]
